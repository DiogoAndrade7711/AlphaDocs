# AlphaDocs — Guia de instalação completo

Siga na ordem. Cada etapa tem capturas de onde clicar.

---

## Etapa 1 — Criar conta no GitHub (grátis)

1. Acesse **https://github.com**
2. Clique em **Sign up** e crie uma conta
3. Confirme seu e-mail

---

## Etapa 2 — Criar o repositório no GitHub

1. Estando logado no GitHub, clique no **+** no canto superior direito
2. Clique em **New repository**
3. Preencha:
   - **Repository name:** `alphadocs`
   - Deixe em **Private** (recomendado)
   - **NÃO marque** "Add a README file"
4. Clique em **Create repository**
5. Copie a URL que aparecer — vai ser algo como:
   ```
   https://github.com/seunome/alphadocs.git
   ```

---

## Etapa 3 — Instalar o Node.js no seu computador

1. Acesse **https://nodejs.org**
2. Baixe a versão **LTS** (botão verde maior)
3. Instale normalmente (Next → Next → Finish)
4. Instale também o **Git** em **https://git-scm.com** → Download

---

## Etapa 4 — Enviar o projeto para o GitHub

1. Descompacte o arquivo `alphadocs.zip` que você baixou
2. Abra a pasta `alphadocs` que foi criada
3. Dentro dela, clique com o botão direito em um espaço vazio
   - **Windows:** "Abrir no Terminal" ou "Git Bash aqui"
   - **Mac:** "Novo Terminal na Pasta"
4. No terminal que abrir, digite e pressione Enter:
   ```
   bash deploy.sh
   ```
5. O script vai instalar tudo e perguntar a URL do GitHub
6. Cole a URL que você copiou na Etapa 2 e pressione Enter
7. Pode pedir seu usuário e senha do GitHub — é normal

✅ Quando aparecer "Código enviado para o GitHub com sucesso!" está pronto.

---

## Etapa 5 — Criar conta no Supabase (banco de dados — grátis)

1. Acesse **https://supabase.com**
2. Clique em **Start your project** → criar conta com GitHub
3. Clique em **New project**
4. Preencha:
   - **Name:** alphadocs
   - **Database Password:** anote essa senha em lugar seguro
   - **Region:** South America (São Paulo)
5. Aguarde a criação (pode levar 2 minutos)

### 5.1 — Executar o banco de dados

1. No seu projeto Supabase, clique em **SQL Editor** no menu lateral
2. Clique em **New query**
3. Abra o arquivo `server/db/migrations.sql` da pasta do projeto
4. Copie TODO o conteúdo e cole no editor
5. Clique em **Run** (ou Ctrl+Enter)
6. Deve aparecer "Success" no final

### 5.2 — Criar o bucket de PDFs

1. No menu lateral, clique em **Storage**
2. Clique em **New bucket**
3. Preencha:
   - **Name:** `alphadocs-pdfs`
   - Desmarque "Public bucket" (deve ficar privado)
4. Clique em **Save**

### 5.3 — Pegar as chaves do Supabase

1. No menu lateral, clique em **Settings** (engrenagem)
2. Clique em **API**
3. Anote (ou copie num bloco de notas):
   - **Project URL** → vai virar `SUPABASE_URL`
   - **anon public** (em Project API keys) → vai virar `SUPABASE_ANON_KEY`
   - **service_role secret** (clique em "Reveal") → vai virar `SUPABASE_SERVICE_ROLE_KEY`

---

## Etapa 6 — Criar conta no Render (hospedagem — grátis)

1. Acesse **https://dashboard.render.com**
2. Clique em **Get Started for Free**
3. Faça login com sua conta do **GitHub** (mais fácil)

### 6.1 — Criar os serviços com Blueprint

1. No painel do Render, clique em **New** → **Blueprint**
2. Conecte sua conta GitHub se pedido
3. Selecione o repositório **alphadocs**
4. Clique em **Connect**
5. O Render vai ler o arquivo `render.yaml` e mostrar dois serviços:
   - `alphadocs-api` (backend)
   - `alphadocs-frontend` (frontend)
6. Clique em **Apply**
7. Aguarde o deploy (5 a 10 minutos na primeira vez)

---

## Etapa 7 — Preencher as variáveis de ambiente no Render

1. No painel do Render, clique no serviço **alphadocs-api**
2. No menu lateral, clique em **Environment**
3. Adicione cada variável abaixo clicando em **Add Environment Variable**:

| Variável | O que colocar |
|---|---|
| `SUPABASE_URL` | A "Project URL" que você anotou |
| `SUPABASE_ANON_KEY` | A "anon public" que você anotou |
| `SUPABASE_SERVICE_ROLE_KEY` | A "service_role secret" que você anotou |
| `JWT_SECRET` | Qualquer texto longo aleatório (ex: `minha-chave-super-secreta-alphadocs-2024-xyzabc`) |
| `DOCS_API_KEY` | Sua chave do painel do serviço de documentos |
| `MP_ACCESS_TOKEN` | (opcional por enquanto — preencha quando configurar o Mercado Pago) |
| `SMTP_HOST` | (opcional por enquanto — preencha quando configurar o e-mail) |

4. Clique em **Save Changes**
5. O serviço vai reiniciar automaticamente

---

## Etapa 8 — Conectar frontend com backend

1. No painel do Render, clique no serviço **alphadocs-frontend**
2. Copie a URL que aparece no topo (ex: `https://alphadocs-frontend.onrender.com`)
3. Volte para o serviço **alphadocs-api**
4. Vá em **Environment** novamente
5. Adicione a variável:
   - `CLIENT_URL` = a URL do frontend que você copiou
6. Salve — o serviço reinicia

---

## Etapa 9 — Criar o primeiro admin

1. Acesse a URL do frontend e crie uma conta normalmente
2. Volte no **Supabase → SQL Editor**
3. Cole e execute este comando (troque pelo seu e-mail):
```sql
insert into admins (user_id)
select id from profiles where email = 'SEU_EMAIL_AQUI';
```
4. Clique em **Run**

---

## Etapa 10 — Primeira configuração no painel

1. Acesse sua URL do frontend
2. Faça login com a conta que você tornou admin
3. Acesse **/admin** (ou clique em "Admin" no menu)
4. Vá em **Módulos → Atualizar catálogo**
   - Isso sincroniza todos os documentos disponíveis
5. Vá em **Configurações** e ajuste nome, preço do crédito e WhatsApp de suporte

---

## ✅ Pronto!

Seu AlphaDocs está no ar. A URL do frontend é o endereço do seu sistema.

**Resumo do que você tem:**
- ✅ Sistema hospedado (grátis no plano básico do Render)
- ✅ Banco de dados seguro (Supabase)
- ✅ PDFs armazenados com segurança
- ✅ Painel admin completo
- ✅ Pix automático (assim que configurar o Mercado Pago)

---

## Problemas comuns

**"Cannot find module"** — volte ao terminal e rode `npm install --prefix server`

**Tela branca no frontend** — verifique se `CLIENT_URL` está preenchida corretamente no backend

**Admin não aparece** — confirme que executou o SQL da Etapa 9 com o e-mail correto

**Documentos não aparecem** — vá em Admin → Módulos → Atualizar catálogo

Para qualquer outro problema, o log do serviço no Render (aba **Logs**) mostra o erro exato.
